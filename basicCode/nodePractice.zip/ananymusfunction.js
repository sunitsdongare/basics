//in this we will creat a param function and export them 
//while using that function we will pass the parameter

module.exports=function(name, pass){
console.log("Name of the user is :"+ name+" "+"password of the user is :"+pass)
}
