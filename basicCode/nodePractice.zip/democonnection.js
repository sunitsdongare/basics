//CODE TO SEE if node is connected to db or not
var mysql= require('mysql');

var con= mysql.createConnection