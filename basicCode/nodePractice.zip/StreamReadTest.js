var fs = require("fs");
var data = '';

// Create a readable stream
var readerStream = fs.createReadStream('Sample1.txt');

