var message=require('./message.js')

console.log(message);