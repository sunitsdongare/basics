var credentials=require('./ananymusfunction.js')

credentials('Deepak','welcome')
credentials('apurva','welcome2');
