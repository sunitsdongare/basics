//let use the calcultor module from current dir

var calculate=require('./calculator.js');
calculate.module.Addition(2,5)
calculate.module.Division(25,5)
calculate.module.Multiplication(2,6)
calculate.module.Substraction(1,19)
