//we can add object data to export function
// data.js contains data and we gona use it some other function
module.exports={
    DeveloperName:'Deepak Pal',
    languageused:'Node Js',
    codingtool:'VS Code',
}
