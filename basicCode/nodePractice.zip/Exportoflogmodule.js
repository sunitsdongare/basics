var log= require('./mylogmodule.js')

log.info("Information coming from the Log")
log.warning("warning coming from the log")