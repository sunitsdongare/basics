var data=require('./data.js')
console.log(data.DeveloperName+" "+"language used foe development "+" "+data.languageused+"tool used for the development"+data.codingtool);