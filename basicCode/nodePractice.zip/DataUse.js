//lets use the data from from data.js

console.log("Name of the developer:"+DeveloperName)